const KEY="stok_v1_data";
let data=JSON.parse(localStorage.getItem(KEY)||"[]");
document.getElementById("date").valueAsDate=new Date();

function login(){
  const u=document.getElementById("username").value.trim(), p=document.getElementById("password").value;
  if(u==="admin"&&p==="admin123"){sessionStorage.logged="1";showApp()}else document.getElementById("loginMsg").textContent="Username atau password salah.";
}
function showApp(){document.getElementById("login").classList.add("hidden");document.getElementById("app").classList.remove("hidden");render()}
function logout(){sessionStorage.removeItem("logged");location.reload()}
if(sessionStorage.logged==="1")showApp();

function save(){localStorage.setItem(KEY,JSON.stringify(data));render()}
function addTransaction(){
  const name=itemName.value.trim(), code=itemCode.value.trim(), qty=Number(document.getElementById("qty").value), type=document.getElementById("type").value, date=document.getElementById("date").value, note=document.getElementById("note").value.trim();
  if(!name||!qty||qty<1||!date){alert("Nama, jumlah, dan tanggal wajib diisi.");return}
  if(type==="keluar"){
    const current=data.filter(x=>x.name.toLowerCase()===name.toLowerCase()).reduce((s,x)=>s+(x.type==="masuk"?x.qty:-x.qty),0);
    if(qty>current){alert("Stok tidak mencukupi.");return}
  }
  data.push({id:Date.now(),name,code,qty,type,date,note});save();
  itemName.value=itemCode.value=qty.value=note.value="";document.getElementById("date").valueAsDate=new Date();
}
function render(){
  const q=document.getElementById("search").value.toLowerCase();
  const map={};
  data.forEach(x=>{if(!map[x.name])map[x.name]={name:x.name,code:x.code,stock:0,ins:0,outs:0,last:x.date};if(x.type==="masuk"){map[x.name].stock+=x.qty;map[x.name].ins+=x.qty}else{map[x.name].stock-=x.qty;map[x.name].outs+=x.qty}if(x.date>map[x.name].last)map[x.name].last=x.date});
  const rows=Object.values(map).filter(x=>(x.name+" "+x.code).toLowerCase().includes(q)).sort((a,b)=>a.name.localeCompare(b.name));
  stockBody.innerHTML=rows.length?rows.map(x=>`<tr><td>${esc(x.code)}</td><td><b>${esc(x.name)}</b></td><td><b>${x.stock}</b></td><td class="in">+${x.ins}</td><td class="out">-${x.outs}</td><td>${x.last}</td><td>—</td></tr>`).join(""):`<tr><td colspan="7">Belum ada data.</td></tr>`;
  const sorted=[...data].sort((a,b)=>b.date.localeCompare(a.date)||b.id-a.id);
  historyBody.innerHTML=sorted.length?sorted.map(x=>`<tr><td>${x.date}</td><td>${esc(x.name)}</td><td>${esc(x.code)}</td><td class="${x.type==="masuk"?"in":"out"}">${x.type}</td><td>${x.qty}</td><td>${esc(x.note)}</td><td><button class="danger" onclick="removeTx(${x.id})">Hapus</button></td></tr>`).join(""):`<tr><td colspan="7">Belum ada transaksi.</td></tr>`;
  totalIn.textContent=data.filter(x=>x.type==="masuk").reduce((s,x)=>s+x.qty,0);
  totalOut.textContent=data.filter(x=>x.type==="keluar").reduce((s,x)=>s+x.qty,0);
  totalStock.textContent=Object.values(map).reduce((s,x)=>s+x.stock,0);
  itemTypes.textContent=Object.keys(map).length;
}
function removeTx(id){if(confirm("Hapus transaksi ini?")){data=data.filter(x=>x.id!==id);save()}}
function clearAll(){if(confirm("Hapus seluruh data transaksi?")){data=[];save()}}
function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
